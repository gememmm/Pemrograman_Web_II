SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE `buku` (
  `id` bigint UNSIGNED NOT NULL,
  `judul` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `penulis` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `penerbit` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `tahun_terbit` year NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `buku` (`id`, `judul`, `penulis`, `penerbit`, `tahun_terbit`) VALUES
(1, 'Filosofi Brainrot', 'Qiqi', 'erlangqi', '2023'),
(2, 'Cara Biar Bisa Mewing', 'Febri', 'erlangmus', '2004'),
(4, 'Petualangan Sigma Sejuta Sariawan 2', 'Febri2', 'erlangenge', '2012'),
(6, 'Petualangan Sigma Sejuta Sariawan 5', 'Febri2', 'erlangenge', '2022'),
(7, 'Petualangan Badrun : Sigma Sejuta Malam di Laut Jawa nan Luas dan Penuh Hawa Kematian ', 'gem', 'gemus', '2003');

CREATE TABLE `migrations` (
  `id` bigint UNSIGNED NOT NULL,
  `version` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `class` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `group` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `namespace` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `time` int NOT NULL,
  `batch` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(3, '2024-06-10-110413', 'App\\Database\\Migrations\\User', 'default', 'App', 1718018228, 1),
(4, '2024-06-10-110634', 'App\\Database\\Migrations\\Buku', 'default', 'App', 1718018228, 1);

CREATE TABLE `user` (
  `id` int UNSIGNED NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `password` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `user` (`id`, `username`, `email`, `password`) VALUES
(1, 'abdul1', 'abdul1@gmail.com', '$2y$10$sATLRMlgHRCLQMJVChUYCuPsVKta1MolMC28UMaRe1Whwjl3OWDhe'),
(2, 'abdul2', 'abdul2@gmail.com', '$2y$10$CoLgUdHzjZ8OnnsH5NF21edR7KrMNjAWhqb9mGiVFTPCiU2zGYOnW'),
(3, 'baron', 'baron@gmail.com', '$2y$10$awRCyGCL/wdmqz2L8fS1.exx2xHNiBM6rJY51gT9HFVA8ZpEuyJAm'),
(4, 'can', 'can@gmail.com', '$2y$10$bdL7GKNAO0dVd6SlK4MdGOBFX1Z4UUdQW15rwueI7HNDekmHVx6G.'),
(5, 'briyani', 'bri@gmail.com', '$2y$10$cHPyI9JXoQ7GcCzBOyPHKOfYBAOA.Aq3cROd4bOUU5p2rfLH4WO46');


ALTER TABLE `buku`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);


ALTER TABLE `buku`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

ALTER TABLE `migrations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

ALTER TABLE `user`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
